# Data-Science-Examples


CSV Feature Extraction
Random Forest and SVM regression




TODO:
add cross validation (k-fold)
add Feature Analysis
add other Scikitlear models
